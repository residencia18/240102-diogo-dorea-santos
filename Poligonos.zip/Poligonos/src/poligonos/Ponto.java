package poligonos;

import java.util.Scanner;

public class Ponto {
	
	private float x, y;

	public float getX() {
		return x;
	};

	public float getY() {
		return y;
	};

	public Ponto(float x, float y) {
		super();
		this.x = x;
		this.y = y;
	};
	
	public static Ponto solicitaPonto(Scanner sc) {
		System.out.println("Digite as coordenadas do ponto");
		float x = sc.nextFloat();
		float y = sc.nextFloat();
		return new Ponto(x, y);
	}

	public void mostra() {
		System.out.println("("+x+","+y+")");
	}

	public double distancia(Ponto p) {
		return Math.sqrt( Math.pow(x-p.getX(), 2)+ Math.pow(y-p.getY(),2));
	}

}
